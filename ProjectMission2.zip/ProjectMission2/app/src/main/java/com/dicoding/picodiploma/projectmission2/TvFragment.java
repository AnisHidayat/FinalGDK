package com.dicoding.picodiploma.projectmission2;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class TvFragment extends Fragment {
    private ArrayList<Movie> list = new ArrayList<>();

    public TvFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_tv, container, false);

        RecyclerView rvTv = root.findViewById(R.id.rv_tv);
        list.addAll(MovieData.getListData(requireContext()));

        rvTv.setLayoutManager(new GridLayoutManager(getContext(), 2));
        TvAdapter listtvAdapter = new TvAdapter(list);
        rvTv.setAdapter(listtvAdapter);

        listtvAdapter.setOnItemClickCallback(new TvAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Movie data) {
                Intent intent = new Intent(getActivity(), DetailActivity.class);
                intent.putExtra("Movie Item", data);
                startActivity(intent);
            }
        });

        return root;
    }

}
