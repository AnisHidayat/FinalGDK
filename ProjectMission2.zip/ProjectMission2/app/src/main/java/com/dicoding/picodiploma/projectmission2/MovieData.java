package com.dicoding.picodiploma.projectmission2;

import android.content.Context;
import android.content.res.TypedArray;

import java.util.ArrayList;

class MovieData {

    static ArrayList<Movie> getListData(Context context) {

        String[] dataName = context.getResources().getStringArray(R.array.str_name);
        String[] dataDate = context.getResources().getStringArray(R.array.str_date);
        String[] dataDescription = context.getResources().getStringArray(R.array.str_desc);
        TypedArray dataPhoto = context.getResources().obtainTypedArray(R.array.str_photo);

        ArrayList<Movie> movies = new ArrayList<>();
        for (int i = 0; i < dataName.length; i++) {
            Movie movie = new Movie();
            movie.setPhoto(dataPhoto.getResourceId(i, -1));
            movie.setName(dataName[i]);
            movie.setDate(dataDate[i]);
            movie.setDesc(dataDescription[i]);
            movies.add(movie);
        }
        dataPhoto.recycle();
        return movies;
    }
}
