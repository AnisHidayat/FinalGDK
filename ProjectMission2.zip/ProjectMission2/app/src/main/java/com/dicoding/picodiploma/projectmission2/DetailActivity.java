package com.dicoding.picodiploma.projectmission2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent = getIntent();
        Movie movie = intent.getParcelableExtra("Movie Item");

        int image = movie.getPhoto();
        String textName = movie.getName();
        String textDate = movie.getDate();
        String textDesc = movie.getDesc();

        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle(textName);
        }

        ImageView imageView = findViewById(R.id.img_photo2);
        imageView.setImageResource(image);

        TextView tvName = findViewById(R.id.txt_name2);
        tvName.setText(textName);

        TextView tvDate = findViewById(R.id.txt_date2);
        tvDate.setText(textDate);

        TextView tvDesc = findViewById(R.id.txt_description2);
        tvDesc.setText(textDesc);

    }
}
